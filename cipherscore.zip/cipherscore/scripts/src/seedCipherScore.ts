import { db, scansTable } from "@workspace/db";

const sampleEmails = [
  "alice@gmail.com",
  "bob@yahoo.com",
  "carol@company.com",
  "dave@outlook.com",
  "eve@icloud.com",
];

function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

function emailToSeed(email: string): number {
  let hash = 0;
  for (let i = 0; i < email.length; i++) {
    hash = ((hash << 5) - hash + email.charCodeAt(i)) | 0;
  }
  return Math.abs(hash);
}

function categorize(score: number) {
  if (score <= 33) return "low";
  if (score <= 66) return "medium";
  if (score <= 84) return "high";
  return "critical";
}

async function seed() {
  console.log("Seeding CipherScore scan history...");

  for (const email of sampleEmails) {
    const rand = seededRandom(emailToSeed(email));
    const scanCount = 5;

    for (let i = 0; i < scanCount; i++) {
      const baseScore = Math.round(rand() * 70 + 15);
      const offset = i * 3;
      const riskScore = Math.max(5, Math.min(100, baseScore - offset));
      const riskCategory = categorize(riskScore);
      const breachCount = Math.round(rand() * 5);

      const daysAgo = (scanCount - i) * 7;
      const scannedAt = new Date();
      scannedAt.setDate(scannedAt.getDate() - daysAgo);

      await db.insert(scansTable).values({
        email,
        riskScore,
        riskCategory,
        breachCount,
        factors: [],
        actions: [],
        insights: [],
        scannedAt,
      });
    }
    console.log(`  Seeded ${scanCount} scans for ${email}`);
  }

  console.log("Done seeding!");
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
