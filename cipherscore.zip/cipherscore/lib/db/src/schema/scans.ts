import { pgTable, text, serial, real, integer, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const scansTable = pgTable("scans", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  riskScore: real("risk_score").notNull(),
  riskCategory: text("risk_category").notNull(),
  breachCount: integer("breach_count").notNull().default(0),
  factors: jsonb("factors").notNull().default([]),
  actions: jsonb("actions").notNull().default([]),
  insights: jsonb("insights").notNull().default([]),
  scannedAt: timestamp("scanned_at").notNull().defaultNow(),
});

export const insertScanSchema = createInsertSchema(scansTable).omit({ id: true });
export type InsertScan = z.infer<typeof insertScanSchema>;
export type Scan = typeof scansTable.$inferSelect;
