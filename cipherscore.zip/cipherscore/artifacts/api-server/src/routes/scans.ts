import { Router, type IRouter } from "express";
import { db, scansTable } from "@workspace/db";
import { desc, eq, sql } from "drizzle-orm";
import { analyzeEmail, applyActionToScan, type ScanResult } from "../lib/riskEngine.js";
import {
  CreateScanBody,
  GetScanHistoryQueryParams,
  ApplyActionBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/scans", async (req, res) => {
  const parsed = CreateScanBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "validation_error", message: "Invalid request body" });
    return;
  }

  const { email } = parsed.data;
  const result = analyzeEmail(email);

  try {
    const [inserted] = await db
      .insert(scansTable)
      .values({
        email: result.email,
        riskScore: result.riskScore,
        riskCategory: result.riskCategory,
        breachCount: result.breachCount,
        factors: result.factors as any,
        actions: result.actions as any,
        insights: result.insights as any,
        scannedAt: new Date(result.scannedAt),
      })
      .returning();

    res.json({
      ...result,
      id: String(inserted.id),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to persist scan");
    res.json(result);
  }
});

router.get("/scans/history", async (req, res) => {
  const parsed = GetScanHistoryQueryParams.safeParse(req.query);
  const email = parsed.success ? parsed.data.email : undefined;
  const limit = parsed.success ? (parsed.data.limit ?? 20) : 20;

  try {
    let query = db
      .select()
      .from(scansTable)
      .orderBy(desc(scansTable.scannedAt))
      .limit(Number(limit));

    if (email) {
      const rows = await db
        .select()
        .from(scansTable)
        .where(eq(scansTable.email, email))
        .orderBy(desc(scansTable.scannedAt))
        .limit(Number(limit));

      res.json(
        rows.map((r) => ({
          id: String(r.id),
          email: r.email,
          riskScore: r.riskScore,
          riskCategory: r.riskCategory,
          breachCount: r.breachCount,
          scannedAt: r.scannedAt.toISOString(),
        }))
      );
      return;
    }

    const rows = await query;
    res.json(
      rows.map((r) => ({
        id: String(r.id),
        email: r.email,
        riskScore: r.riskScore,
        riskCategory: r.riskCategory,
        breachCount: r.breachCount,
        scannedAt: r.scannedAt.toISOString(),
      }))
    );
  } catch (err) {
    req.log.error({ err }, "Failed to fetch scan history");
    res.json([]);
  }
});

router.post("/actions/apply", async (req, res) => {
  const parsed = ApplyActionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "validation_error", message: "Invalid request body" });
    return;
  }

  const { scanId, actionId } = parsed.data;

  try {
    const [scan] = await db
      .select()
      .from(scansTable)
      .where(eq(scansTable.id, Number(scanId)))
      .limit(1);

    if (!scan) {
      res.status(404).json({ error: "not_found", message: "Scan not found" });
      return;
    }

    const scanResult: ScanResult = {
      id: String(scan.id),
      email: scan.email,
      riskScore: scan.riskScore,
      riskCategory: scan.riskCategory as any,
      breachCount: scan.breachCount,
      factors: scan.factors as any,
      actions: scan.actions as any,
      insights: scan.insights as any,
      scannedAt: scan.scannedAt.toISOString(),
    };

    const { newScore, newCategory, scoreReduction } = applyActionToScan(scanResult, actionId);

    const updatedActions = (scanResult.actions as any[]).map((a: any) =>
      a.id === actionId ? { ...a, applied: true } : a
    );

    await db
      .update(scansTable)
      .set({
        riskScore: newScore,
        riskCategory: newCategory,
        actions: updatedActions as any,
      })
      .where(eq(scansTable.id, Number(scanId)));

    res.json({
      scanId,
      actionId,
      newScore,
      newCategory,
      scoreReduction,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to apply action");
    res.status(500).json({ error: "internal_error", message: "Failed to apply action" });
  }
});

export default router;
