import crypto from "crypto";

export type RiskSeverity = "low" | "medium" | "high" | "critical";
export type RiskCategory = "low" | "medium" | "high" | "critical";
export type ActionPriority = "low" | "medium" | "high" | "critical";
export type InsightSeverity = "info" | "warning" | "danger";

export interface RiskFactor {
  name: string;
  label: string;
  score: number;
  weight: number;
  description: string;
  severity: RiskSeverity;
}

export interface SecurityAction {
  id: string;
  label: string;
  description: string;
  scoreImpact: number;
  applied: boolean;
  priority: ActionPriority;
}

export interface Insight {
  id: string;
  text: string;
  category: string;
  severity: InsightSeverity;
}

export interface ScanResult {
  id: string;
  email: string;
  riskScore: number;
  riskCategory: RiskCategory;
  breachCount: number;
  factors: RiskFactor[];
  actions: SecurityAction[];
  insights: Insight[];
  scannedAt: string;
}

function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

function emailToSeed(email: string): number {
  let hash = 0;
  for (let i = 0; i < email.length; i++) {
    hash = ((hash << 5) - hash + email.charCodeAt(i)) | 0;
  }
  return Math.abs(hash);
}

function categorize(score: number): RiskCategory {
  if (score <= 33) return "low";
  if (score <= 66) return "medium";
  if (score <= 84) return "high";
  return "critical";
}

function toSeverity(score: number): RiskSeverity {
  if (score <= 25) return "low";
  if (score <= 50) return "medium";
  if (score <= 75) return "high";
  return "critical";
}

export function analyzeEmail(email: string): ScanResult {
  const seed = emailToSeed(email);
  const rand = seededRandom(seed);

  const domain = email.split("@")[1] ?? "unknown";
  const commonDomains = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "aol.com", "icloud.com"];
  const isCommon = commonDomains.includes(domain.toLowerCase());

  const breachScore = Math.round(rand() * 65 + (isCommon ? 20 : 10));
  const oauthScore = Math.round(rand() * 60 + 15);
  const sessionScore = Math.round(rand() * 55 + 10);
  const mfaScore = Math.round(rand() * 80 + 5);
  const shadowAiScore = Math.round(rand() * 50 + 5);

  const breachCount = Math.round(rand() * (isCommon ? 8 : 4));

  const factors: RiskFactor[] = [
    {
      name: "breach_exposure",
      label: "Breach Exposure",
      score: Math.min(breachScore, 100),
      weight: 0.35,
      description: `Found in ${breachCount} known data breaches. Attackers may hold your password hashes, personal data, or session tokens.`,
      severity: toSeverity(breachScore),
    },
    {
      name: "oauth_app_risk",
      label: "OAuth App Risk",
      score: Math.min(oauthScore, 100),
      weight: 0.25,
      description: "Third-party apps with broad OAuth permissions can access your account data and act on your behalf.",
      severity: toSeverity(oauthScore),
    },
    {
      name: "session_age",
      label: "Session Age",
      score: Math.min(sessionScore, 100),
      weight: 0.15,
      description: "Old or persistent sessions from unfamiliar devices or locations increase unauthorized access risk.",
      severity: toSeverity(sessionScore),
    },
    {
      name: "mfa_status",
      label: "MFA Status",
      score: Math.min(mfaScore, 100),
      weight: 0.15,
      description: "Accounts without multi-factor authentication are significantly more vulnerable to credential stuffing attacks.",
      severity: toSeverity(mfaScore),
    },
    {
      name: "shadow_ai_usage",
      label: "Shadow AI Usage",
      score: Math.min(shadowAiScore, 100),
      weight: 0.10,
      description: "Unauthorized AI tools with email access can exfiltrate sensitive communications and data.",
      severity: toSeverity(shadowAiScore),
    },
  ];

  const weightedScore = factors.reduce((acc, f) => acc + f.score * f.weight, 0);
  const riskScore = Math.min(100, Math.round(weightedScore));
  const riskCategory = categorize(riskScore);

  const actions: SecurityAction[] = [
    {
      id: "revoke_oauth",
      label: "Revoke Suspicious Apps",
      description: "Audit and revoke third-party OAuth applications that have broad or unnecessary permissions to your account.",
      scoreImpact: Math.round(oauthScore * 0.25),
      applied: false,
      priority: toSeverity(oauthScore) === "critical" || toSeverity(oauthScore) === "high" ? "high" : "medium",
    },
    {
      id: "enable_mfa",
      label: "Enable MFA",
      description: "Add authenticator app or hardware key as a second factor. This single change reduces account takeover risk by over 99%.",
      scoreImpact: Math.round(mfaScore * 0.30),
      applied: false,
      priority: mfaScore > 50 ? "critical" : "high",
    },
    {
      id: "expire_sessions",
      label: "Expire Old Sessions",
      description: "Force sign-out all devices and active sessions, then re-authenticate only from trusted devices.",
      scoreImpact: Math.round(sessionScore * 0.20),
      applied: false,
      priority: toSeverity(sessionScore),
    },
    {
      id: "rotate_password",
      label: "Rotate Password",
      description: "Change your password to a strong, unique passphrase and use a password manager. Critical after any breach detection.",
      scoreImpact: Math.round(breachScore * 0.15),
      applied: false,
      priority: breachCount > 3 ? "critical" : "high",
    },
    {
      id: "review_shadow_ai",
      label: "Review AI Tool Access",
      description: "Audit connected AI tools and revoke email access for services you no longer actively use.",
      scoreImpact: Math.round(shadowAiScore * 0.20),
      applied: false,
      priority: toSeverity(shadowAiScore),
    },
  ];

  const insights: Insight[] = [];
  const topFactor = [...factors].sort((a, b) => b.score * b.weight - a.score * a.weight)[0];

  insights.push({
    id: "primary_driver",
    text: `Your identity risk is primarily driven by ${topFactor.label.toLowerCase()} — this single factor contributes the most to your overall exposure.`,
    category: "Risk Driver",
    severity: topFactor.severity === "low" ? "info" : topFactor.severity === "medium" ? "warning" : "danger",
  });

  if (breachCount > 0) {
    insights.push({
      id: "breach_detail",
      text: `Your email appears in ${breachCount} known breach${breachCount === 1 ? "" : "es"}. ${breachCount > 3 ? "Multiple breaches significantly increase your attack surface — credential stuffing attacks are highly likely." : "Change your password on any affected services immediately."}`,
      category: "Breach Intelligence",
      severity: breachCount > 3 ? "danger" : "warning",
    });
  }

  if (mfaScore > 60) {
    insights.push({
      id: "mfa_insight",
      text: "Enabling multi-factor authentication is the single highest-impact action you can take. It blocks 99.9% of automated account takeover attempts.",
      category: "Authentication",
      severity: "danger",
    });
  }

  if (oauthScore > 50) {
    insights.push({
      id: "oauth_insight",
      text: "Several third-party applications have broad OAuth permissions. Each connected app is a potential entry point for attackers.",
      category: "App Permissions",
      severity: oauthScore > 70 ? "danger" : "warning",
    });
  }

  if (riskScore <= 33) {
    insights.push({
      id: "low_risk",
      text: "Your current security posture is strong. Continue monitoring for new breaches and review your OAuth app permissions regularly.",
      category: "General",
      severity: "info",
    });
  }

  const id = crypto.randomUUID();

  return {
    id,
    email,
    riskScore,
    riskCategory,
    breachCount,
    factors,
    actions,
    insights,
    scannedAt: new Date().toISOString(),
  };
}

export function applyActionToScan(
  scan: ScanResult,
  actionId: string
): { newScore: number; newCategory: RiskCategory; scoreReduction: number } {
  const action = scan.actions.find((a) => a.id === actionId);
  if (!action || action.applied) {
    return {
      newScore: scan.riskScore,
      newCategory: scan.riskCategory,
      scoreReduction: 0,
    };
  }
  const reduction = action.scoreImpact;
  const newScore = Math.max(0, Math.round(scan.riskScore - reduction));
  return {
    newScore,
    newCategory: categorize(newScore),
    scoreReduction: reduction,
  };
}
