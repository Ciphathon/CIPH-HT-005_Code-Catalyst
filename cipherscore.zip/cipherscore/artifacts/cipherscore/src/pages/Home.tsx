import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Shield, Search, ArrowRight, Activity, AlertTriangle, CheckCircle, Sun, Moon } from "lucide-react";
import { useCreateScan, useGetScanHistory } from "@workspace/api-client-react";
import { useAppStore } from "@/lib/store";
import { useTheme } from "@/lib/theme";
import { cn, getRiskCategoryColorClass } from "@/lib/utils";

export function Home() {
  const [email, setEmail] = useState("");
  const [, setLocation] = useLocation();
  const { setCurrentScan } = useAppStore();
  const { theme, toggleTheme } = useTheme();
  
  const createScanMutation = useCreateScan({
    mutation: {
      onSuccess: (data) => {
        setCurrentScan(data);
        setLocation("/dashboard");
      }
    }
  });

  const { data: history, isLoading: isHistoryLoading } = useGetScanHistory({ limit: 5 });

  const handleScan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    createScanMutation.mutate({ data: { email } });
  };

  const handleHistoryClick = (historicEmail: string) => {
    setEmail(historicEmail);
    createScanMutation.mutate({ data: { email: historicEmail } });
  };

  return (
    <div className="min-h-screen relative flex flex-col items-center text-foreground overflow-hidden">
      {/* Background Image & Overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-40"
        style={{ backgroundImage: `url('${import.meta.env.BASE_URL}images/hero-bg.png')` }}
      />
      <div className="absolute inset-0 z-0 bg-gradient-to-b from-background/40 via-background/80 to-background" />

      {/* Nav/Header */}
      <nav className="w-full max-w-7xl mx-auto px-6 py-8 relative z-10 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Shield className="w-8 h-8 text-primary" />
          <span className="font-display font-bold text-2xl tracking-tight">
            Cipher<span className="text-primary">Score</span>
          </span>
        </div>
        <div className="hidden md:flex gap-8 text-sm font-medium text-muted-foreground">
          <a href="#" className="hover:text-primary transition-colors">Product</a>
          <a href="#" className="hover:text-primary transition-colors">Solutions</a>
          <a href="#" className="hover:text-primary transition-colors">Documentation</a>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
          <button className="px-5 py-2.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors font-medium text-sm">
            Sign In
          </button>
        </div>
      </nav>

      <main className="flex-1 w-full max-w-4xl mx-auto px-4 flex flex-col justify-center relative z-10 pt-20 pb-32">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center space-y-6"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary mb-4 text-sm font-semibold tracking-wide">
            <Activity className="w-4 h-4" />
            <span>Advanced Identity Intelligence</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-br from-white to-zinc-500 pb-2">
            Discover your risk footprint <br className="hidden md:block" /> before attackers do.
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Enter any corporate email address to instantly analyze external breach exposure, shadow AI usage, and credential vulnerabilities.
          </p>

          {/* Search Form */}
          <form onSubmit={handleScan} className="mt-12 max-w-xl mx-auto relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-primary/50 to-accent/50 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-500"></div>
            <div className="relative flex items-center bg-zinc-950 border border-white/10 rounded-2xl shadow-2xl p-2">
              <div className="pl-4 pr-2 text-muted-foreground">
                <Search className="w-6 h-6" />
              </div>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={createScanMutation.isPending}
                placeholder="Enter email address to scan..."
                className="flex-1 bg-transparent border-none outline-none text-foreground placeholder:text-zinc-600 px-2 py-4 text-lg"
              />
              <button
                type="submit"
                disabled={createScanMutation.isPending}
                className="px-8 py-4 rounded-xl bg-primary text-primary-foreground font-bold flex items-center gap-2 hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {createScanMutation.isPending ? "Analyzing..." : "Analyze Risk"}
                {!createScanMutation.isPending && <ArrowRight className="w-5 h-5" />}
              </button>
            </div>
          </form>
        </motion.div>

        {/* Recent Scans Section */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-32 max-w-3xl mx-auto w-full"
        >
          <h3 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground mb-6 text-center">
            Recent Intelligence Scans
          </h3>
          
          <div className="glass-panel rounded-2xl overflow-hidden">
            {isHistoryLoading ? (
              <div className="p-8 text-center text-muted-foreground animate-pulse">Loading history...</div>
            ) : history && history.length > 0 ? (
              <div className="divide-y divide-white/5">
                {history.map((scan) => (
                  <button 
                    key={scan.id}
                    onClick={() => handleHistoryClick(scan.email)}
                    disabled={createScanMutation.isPending}
                    className="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors text-left"
                  >
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "p-2 rounded-lg border", 
                        getRiskCategoryColorClass(scan.riskCategory)
                      )}>
                        {scan.riskCategory === 'low' ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{scan.email}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(scan.scannedAt).toLocaleDateString()} • {scan.breachCount} breaches found
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-2xl font-display font-bold">{scan.riskScore}</p>
                        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Score</p>
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-muted-foreground">
                No recent scans available.
              </div>
            )}
          </div>
        </motion.div>
      </main>
    </div>
  );
}
