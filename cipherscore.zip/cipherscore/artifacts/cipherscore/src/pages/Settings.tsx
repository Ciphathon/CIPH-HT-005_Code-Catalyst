import { useState } from "react";
import { motion } from "framer-motion";
import {
  Moon, Sun, Bell, Shield, Database, Key,
  RefreshCw, Info, ChevronRight, ToggleLeft, ToggleRight,
} from "lucide-react";
import { Sidebar } from "@/components/Sidebar";
import { useTheme } from "@/lib/theme";
import { cn } from "@/lib/utils";

const item = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } },
};
const container = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.08 } },
};

function Toggle({
  enabled,
  onToggle,
}: {
  enabled: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className={cn(
        "relative w-12 h-6 rounded-full transition-colors duration-300 border",
        enabled
          ? "bg-primary/30 border-primary/50"
          : "bg-white/5 border-white/10"
      )}
    >
      <div
        className={cn(
          "absolute top-0.5 w-5 h-5 rounded-full transition-all duration-300",
          enabled ? "left-6 bg-primary" : "left-0.5 bg-zinc-500"
        )}
      />
    </button>
  );
}

function SettingsRow({
  icon: Icon,
  label,
  description,
  children,
}: {
  icon: React.ElementType;
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between py-4 px-5 hover:bg-white/3 transition-colors rounded-xl group">
      <div className="flex items-start gap-4">
        <div className="p-2 rounded-lg bg-white/5 text-muted-foreground group-hover:text-primary transition-colors mt-0.5">
          <Icon className="w-5 h-5" />
        </div>
        <div>
          <p className="font-medium text-foreground">{label}</p>
          {description && (
            <p className="text-sm text-muted-foreground mt-0.5">{description}</p>
          )}
        </div>
      </div>
      <div className="ml-4 shrink-0">{children}</div>
    </div>
  );
}

export function Settings() {
  const { theme, toggleTheme } = useTheme();
  const [notifBreaches, setNotifBreaches] = useState(true);
  const [notifScore, setNotifScore] = useState(false);
  const [autoRescan, setAutoRescan] = useState(false);
  const [apiMasked, setApiMasked] = useState(true);

  const fakeApiKey = "cs_live_xk8mNp2qR4vTjL9wEaBoY5hCsDf1Uz";

  return (
    <div className="min-h-screen bg-background flex text-foreground">
      <Sidebar />
      <main className="flex-1 md:pl-64 flex flex-col">
        <header className="sticky top-0 z-30 glass-panel border-t-0 border-x-0 px-8 py-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-1">
            Configuration
          </h2>
          <h1 className="text-2xl font-bold">Settings</h1>
        </header>

        <motion.div
          className="p-8 space-y-6 max-w-3xl mx-auto w-full"
          variants={container}
          initial="hidden"
          animate="visible"
        >
          {/* Appearance */}
          <motion.section variants={item}>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-1">
              Appearance
            </h3>
            <div className="glass-panel rounded-2xl overflow-hidden divide-y divide-white/5">
              <SettingsRow
                icon={theme === "dark" ? Moon : Sun}
                label="Theme"
                description={`Currently using ${theme} mode`}
              >
                <button
                  onClick={toggleTheme}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 border border-white/10 hover:border-primary/40 hover:bg-primary/10 transition-all text-sm font-medium"
                >
                  {theme === "dark" ? (
                    <><Sun className="w-4 h-4" /> Light Mode</>
                  ) : (
                    <><Moon className="w-4 h-4" /> Dark Mode</>
                  )}
                </button>
              </SettingsRow>
            </div>
          </motion.section>

          {/* Notifications */}
          <motion.section variants={item}>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-1">
              Notifications
            </h3>
            <div className="glass-panel rounded-2xl overflow-hidden divide-y divide-white/5">
              <SettingsRow
                icon={Bell}
                label="Breach Alerts"
                description="Get notified when new breaches are detected for monitored emails"
              >
                <Toggle enabled={notifBreaches} onToggle={() => setNotifBreaches((v) => !v)} />
              </SettingsRow>
              <SettingsRow
                icon={Shield}
                label="Score Change Alerts"
                description="Alert when risk score changes by more than 10 points"
              >
                <Toggle enabled={notifScore} onToggle={() => setNotifScore((v) => !v)} />
              </SettingsRow>
              <SettingsRow
                icon={RefreshCw}
                label="Auto Re-scan"
                description="Automatically re-scan monitored emails every 7 days"
              >
                <Toggle enabled={autoRescan} onToggle={() => setAutoRescan((v) => !v)} />
              </SettingsRow>
            </div>
          </motion.section>

          {/* API Access */}
          <motion.section variants={item}>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-1">
              API Access
            </h3>
            <div className="glass-panel rounded-2xl overflow-hidden divide-y divide-white/5">
              <SettingsRow
                icon={Key}
                label="API Key"
                description="Use this key to access the CipherScore API programmatically"
              >
                <button
                  onClick={() => setApiMasked((v) => !v)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:border-primary/30 transition-all text-xs font-mono"
                >
                  {apiMasked
                    ? "••••••••••••••••••••"
                    : fakeApiKey.slice(0, 22) + "..."}
                  <span className="text-primary text-xs font-sans">
                    {apiMasked ? "Show" : "Hide"}
                  </span>
                </button>
              </SettingsRow>
              <SettingsRow
                icon={Database}
                label="Data Retention"
                description="Scan history is retained for 90 days by default"
              >
                <select defaultValue="90" className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-foreground outline-none focus:border-primary/50 transition-colors">
                  <option value="30">30 days</option>
                  <option value="90">90 days</option>
                  <option value="180">180 days</option>
                  <option value="365">1 year</option>
                </select>
              </SettingsRow>
            </div>
          </motion.section>

          {/* About */}
          <motion.section variants={item}>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-1">
              About
            </h3>
            <div className="glass-panel rounded-2xl overflow-hidden divide-y divide-white/5">
              {[
                { label: "Version", value: "0.1.0-mvp" },
                { label: "Risk Engine", value: "Weighted Multi-Factor v2" },
                { label: "Data Sources", value: "5 breach databases" },
                { label: "Last Updated", value: "March 2026" },
              ].map(({ label, value }) => (
                <div key={label} className="flex items-center justify-between py-4 px-5">
                  <div className="flex items-center gap-4">
                    <div className="p-2 rounded-lg bg-white/5 text-muted-foreground">
                      <Info className="w-5 h-5" />
                    </div>
                    <p className="font-medium">{label}</p>
                  </div>
                  <span className="text-sm text-muted-foreground font-mono">{value}</span>
                </div>
              ))}
            </div>
          </motion.section>

          {/* Danger zone */}
          <motion.section variants={item}>
            <h3 className="text-xs font-semibold text-rose-500/70 uppercase tracking-wider mb-3 px-1">
              Danger Zone
            </h3>
            <div className="glass-panel rounded-2xl overflow-hidden border-rose-500/20 divide-y divide-white/5">
              <button className="w-full flex items-center justify-between px-5 py-4 hover:bg-rose-500/5 transition-colors group">
                <div className="flex items-center gap-4">
                  <div className="p-2 rounded-lg bg-rose-500/10 text-rose-500">
                    <Database className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-foreground">Clear Scan History</p>
                    <p className="text-sm text-muted-foreground">
                      Permanently delete all stored scan records
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-rose-400 transition-colors" />
              </button>
            </div>
          </motion.section>
        </motion.div>
      </main>
    </div>
  );
}
