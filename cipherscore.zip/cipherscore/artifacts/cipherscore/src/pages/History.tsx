import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  Search, AlertTriangle, CheckCircle, Clock,
  TrendingDown, TrendingUp, ShieldAlert, Filter,
} from "lucide-react";
import { useGetScanHistory, useCreateScan } from "@workspace/api-client-react";
import { useAppStore } from "@/lib/store";
import { Sidebar } from "@/components/Sidebar";
import { MultiLineHistoryChart } from "@/components/Charts";
import { cn, getRiskCategoryColorClass, getRiskCategoryLabel } from "@/lib/utils";

const item = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } },
};
const container = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.07 } },
};

export function History() {
  const [, setLocation] = useLocation();
  const { setCurrentScan } = useAppStore();
  const [searchEmail, setSearchEmail] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");

  const { data: allHistory, isLoading } = useGetScanHistory({ limit: 100 });

  const rescanMutation = useCreateScan({
    mutation: {
      onSuccess: (data) => {
        setCurrentScan(data);
        setLocation("/dashboard");
      },
    },
  });

  const filtered = useMemo(() => {
    if (!allHistory) return [];
    return allHistory.filter((s) => {
      const matchEmail = searchEmail
        ? s.email.toLowerCase().includes(searchEmail.toLowerCase())
        : true;
      const matchCat =
        filterCategory === "all" ? true : s.riskCategory === filterCategory;
      return matchEmail && matchCat;
    });
  }, [allHistory, searchEmail, filterCategory]);

  // Build multi-line chart data keyed by date
  const chartData = useMemo(() => {
    if (!allHistory) return { data: [], emails: [] };
    const emailSet = Array.from(new Set(allHistory.map((s) => s.email))).slice(0, 5);
    const byDate: Record<string, Record<string, number>> = {};

    allHistory.forEach((s) => {
      const date = new Date(s.scannedAt).toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
      });
      if (!byDate[date]) byDate[date] = {};
      byDate[date][s.email] = Math.round(s.riskScore);
    });

    const data = Object.entries(byDate)
      .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
      .map(([date, scores]) => ({ date, ...scores }));

    return { data, emails: emailSet };
  }, [allHistory]);

  const stats = useMemo(() => {
    if (!filtered.length) return null;
    const avg = Math.round(filtered.reduce((a, s) => a + s.riskScore, 0) / filtered.length);
    const highest = Math.max(...filtered.map((s) => s.riskScore));
    const lowest = Math.min(...filtered.map((s) => s.riskScore));
    const criticalCount = filtered.filter((s) => s.riskCategory === "critical").length;
    return { avg, highest, lowest, criticalCount };
  }, [filtered]);

  return (
    <div className="min-h-screen bg-background flex text-foreground">
      <Sidebar />
      <main className="flex-1 md:pl-64 flex flex-col">
        <header className="sticky top-0 z-30 glass-panel border-t-0 border-x-0 px-8 py-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-1">
            Intelligence Records
          </h2>
          <h1 className="text-2xl font-bold">Scan History</h1>
        </header>

        <motion.div
          className="p-8 space-y-6 max-w-7xl mx-auto w-full"
          variants={container}
          initial="hidden"
          animate="visible"
        >
          {/* Stats row */}
          {stats && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: "Average Score", value: stats.avg, icon: ShieldAlert, color: "text-primary" },
                { label: "Highest Risk", value: stats.highest, icon: TrendingUp, color: "text-rose-400" },
                { label: "Lowest Risk", value: stats.lowest, icon: TrendingDown, color: "text-emerald-400" },
                { label: "Critical Alerts", value: stats.criticalCount, icon: AlertTriangle, color: "text-amber-400" },
              ].map(({ label, value, icon: Icon, color }) => (
                <motion.div key={label} variants={item} className="glass-panel rounded-2xl p-5">
                  <Icon className={cn("w-5 h-5 mb-3", color)} />
                  <p className="text-3xl font-bold mb-1">{value}</p>
                  <p className="text-sm text-muted-foreground">{label}</p>
                </motion.div>
              ))}
            </div>
          )}

          {/* Multi-line chart */}
          {chartData.emails.length > 0 && (
            <motion.div variants={item} className="glass-panel rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-5 h-5 text-primary" />
                <h3 className="font-bold text-lg">Risk Score Trends</h3>
              </div>
              <MultiLineHistoryChart data={chartData.data} emails={chartData.emails} />
            </motion.div>
          )}

          {/* Filters */}
          <motion.div variants={item} className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Filter by email..."
                value={searchEmail}
                onChange={(e) => setSearchEmail(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 transition-colors text-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              {["all", "low", "medium", "high", "critical"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilterCategory(cat)}
                  className={cn(
                    "px-3 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors border",
                    filterCategory === cat
                      ? "bg-primary/20 text-primary border-primary/40"
                      : "bg-white/5 text-muted-foreground border-white/10 hover:border-white/20"
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>
          </motion.div>

          {/* Scan table */}
          <motion.div variants={item} className="glass-panel rounded-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-white/5 flex items-center justify-between">
              <h3 className="font-bold">
                {filtered.length} scan{filtered.length !== 1 ? "s" : ""}
              </h3>
              <span className="text-xs text-muted-foreground">Click any row to re-scan</span>
            </div>

            {isLoading ? (
              <div className="divide-y divide-white/5">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="p-4 flex items-center gap-4 animate-pulse">
                    <div className="w-10 h-10 rounded-lg bg-white/5" />
                    <div className="flex-1 space-y-2">
                      <div className="h-4 w-48 rounded bg-white/5" />
                      <div className="h-3 w-32 rounded bg-white/5" />
                    </div>
                    <div className="h-8 w-16 rounded bg-white/5" />
                  </div>
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground">
                No scans match your filters.
              </div>
            ) : (
              <div className="divide-y divide-white/5">
                {filtered.map((scan) => (
                  <button
                    key={scan.id}
                    onClick={() =>
                      rescanMutation.mutate({ data: { email: scan.email } })
                    }
                    disabled={rescanMutation.isPending}
                    className="w-full flex items-center justify-between px-6 py-4 hover:bg-white/5 transition-colors text-left group"
                  >
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          "p-2 rounded-lg border",
                          getRiskCategoryColorClass(scan.riskCategory)
                        )}
                      >
                        {scan.riskCategory === "low" ? (
                          <CheckCircle className="w-5 h-5" />
                        ) : (
                          <AlertTriangle className="w-5 h-5" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{scan.email}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(scan.scannedAt).toLocaleString()} •{" "}
                          {scan.breachCount} breach{scan.breachCount !== 1 ? "es" : ""}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div
                        className={cn(
                          "px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border",
                          getRiskCategoryColorClass(scan.riskCategory)
                        )}
                      >
                        {getRiskCategoryLabel(scan.riskCategory)}
                      </div>
                      <div className="text-right min-w-[3rem]">
                        <p className="text-2xl font-bold">{Math.round(scan.riskScore)}</p>
                        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                          score
                        </p>
                      </div>
                      <span className="text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity font-semibold whitespace-nowrap">
                        Re-scan →
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </motion.div>
        </motion.div>
      </main>
    </div>
  );
}
