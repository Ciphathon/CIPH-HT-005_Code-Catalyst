import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ShieldAlert, ShieldCheck, ServerCrash, AlertTriangle,
  Activity, ArrowRight, Zap, Info, Clock, 
  RefreshCw, CheckCircle2, Sun, Moon
} from "lucide-react";
import { useTheme } from "@/lib/theme";
import { useAppStore } from "@/lib/store";
import { Sidebar } from "@/components/Sidebar";
import { ScoreGauge } from "@/components/ScoreGauge";
import { RiskVectorsChart, ScoreHistoryChart } from "@/components/Charts";
import { cn, getRiskCategoryColorClass, getRiskCategoryLabel } from "@/lib/utils";
import { useApplyAction, useGetScanHistory, useCreateScan } from "@workspace/api-client-react";

export function Dashboard() {
  const [, setLocation] = useLocation();
  const { currentScan, setCurrentScan } = useAppStore();
  const { theme, toggleTheme } = useTheme();
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  const { data: history, refetch: refetchHistory } = useGetScanHistory(
    { email: currentScan?.email, limit: 10 },
    { query: { enabled: !!currentScan?.email } }
  );

  const applyActionMutation = useApplyAction({
    mutation: {
      onSuccess: (data) => {
        if (currentScan) {
          const updatedActions = currentScan.actions.map(a => 
            a.id === data.actionId ? { ...a, applied: true } : a
          );
          
          setCurrentScan({
            ...currentScan,
            riskScore: data.newScore,
            riskCategory: data.newCategory,
            actions: updatedActions
          });
          
          refetchHistory(); // Update history chart dynamically
        }
      }
    }
  });

  const refreshScanMutation = useCreateScan({
    mutation: {
      onSuccess: (data) => {
        setCurrentScan(data);
        setIsRefreshing(false);
        refetchHistory();
      },
      onError: () => setIsRefreshing(false)
    }
  });

  // Redirect to home if no scan data
  useEffect(() => {
    if (!currentScan) {
      setLocation("/");
    }
  }, [currentScan, setLocation]);

  if (!currentScan) return null;

  const handleRefresh = () => {
    setIsRefreshing(true);
    refreshScanMutation.mutate({ data: { email: currentScan.email } });
  };

  const handleApplyAction = (actionId: string) => {
    applyActionMutation.mutate({ data: { scanId: currentScan.id, actionId } });
  };

  const activeActionsCount = currentScan.actions.filter(a => !a.applied).length;
  const isHighRisk = currentScan.riskScore >= 67;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } }
  };

  return (
    <div className="min-h-screen bg-background flex text-foreground">
      <Sidebar />
      
      <main className="flex-1 md:pl-64 flex flex-col min-h-screen overflow-x-hidden">
        {/* Top Header */}
        <header className="sticky top-0 z-30 glass-panel border-t-0 border-x-0 px-8 py-5 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-1">
              Identity Intelligence Profile
            </h2>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-display font-bold">{currentScan.email}</h1>
              <div className={cn(
                "px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-full border",
                getRiskCategoryColorClass(currentScan.riskCategory)
              )}>
                {getRiskCategoryLabel(currentScan.riskCategory)}
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button 
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary hover:bg-secondary/80 border border-white/5 transition-colors text-sm font-medium"
            >
              <RefreshCw className={cn("w-4 h-4", isRefreshing && "animate-spin")} />
              {isRefreshing ? "Rescanning..." : "Refresh Scan"}
            </button>
          </div>
        </header>

        <motion.div 
          className="p-8 flex-1 w-full max-w-7xl mx-auto space-y-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Top KPI Row */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <motion.div variants={itemVariants} className="glass-panel rounded-2xl flex items-center justify-center p-6">
              <ScoreGauge score={currentScan.riskScore} category={currentScan.riskCategory} />
            </motion.div>
            
            <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-3 gap-6">
              <motion.div variants={itemVariants} className="glass-panel rounded-2xl p-6 flex flex-col justify-between group">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-rose-500/20 p-3 rounded-xl border border-rose-500/30 text-rose-500">
                    <ServerCrash className="w-6 h-6" />
                  </div>
                </div>
                <div>
                  <h3 className="text-4xl font-display font-bold mb-1 group-hover:scale-105 transition-transform origin-left">
                    {currentScan.breachCount}
                  </h3>
                  <p className="text-muted-foreground font-medium">Known Data Breaches</p>
                </div>
              </motion.div>

              <motion.div variants={itemVariants} className="glass-panel rounded-2xl p-6 flex flex-col justify-between group">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-amber-500/20 p-3 rounded-xl border border-amber-500/30 text-amber-500">
                    <Zap className="w-6 h-6" />
                  </div>
                </div>
                <div>
                  <h3 className="text-4xl font-display font-bold mb-1 group-hover:scale-105 transition-transform origin-left">
                    {activeActionsCount}
                  </h3>
                  <p className="text-muted-foreground font-medium">Actionable Findings</p>
                </div>
              </motion.div>

              <motion.div variants={itemVariants} className="glass-panel rounded-2xl p-6 flex flex-col justify-between group">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-zinc-500/20 p-3 rounded-xl border border-zinc-500/30 text-zinc-400">
                    <Clock className="w-6 h-6" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-display font-bold mb-1 group-hover:scale-105 transition-transform origin-left text-white">
                    {new Date(currentScan.scannedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </h3>
                  <p className="text-muted-foreground font-medium">Last Scan Time</p>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <motion.div variants={itemVariants} className="glass-panel rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-6">
                <Activity className="w-5 h-5 text-primary" />
                <h3 className="font-display font-bold text-lg">Risk Vectors Breakdown</h3>
              </div>
              <RiskVectorsChart factors={currentScan.factors} />
            </motion.div>

            <motion.div variants={itemVariants} className="glass-panel rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-6">
                <Clock className="w-5 h-5 text-primary" />
                <h3 className="font-display font-bold text-lg">Score History</h3>
              </div>
              {history && history.length > 0 ? (
                <ScoreHistoryChart history={history} />
              ) : (
                <div className="w-full h-64 flex items-center justify-center text-muted-foreground">
                  Insufficient history data
                </div>
              )}
            </motion.div>
          </div>

          {/* Bottom Row - Actions & Insights */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-12">
            <motion.div variants={itemVariants} className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-display font-bold text-xl">Security Actions</h3>
                <span className="text-sm text-muted-foreground bg-white/5 px-3 py-1 rounded-full border border-white/5">
                  {activeActionsCount} Pending
                </span>
              </div>
              
              <AnimatePresence>
                {currentScan.actions.map(action => (
                  <motion.div 
                    key={action.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className={cn(
                      "glass-panel rounded-xl p-5 border-l-4 transition-all duration-300",
                      action.applied ? "border-l-emerald-500 opacity-60" : "border-l-amber-500 hover:shadow-lg hover:-translate-y-1"
                    )}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-bold text-lg line-through-if-applied">{action.label}</h4>
                          {action.applied && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">{action.description}</p>
                        <div className="flex gap-2">
                          <span className="text-xs font-semibold px-2 py-1 rounded bg-white/5 text-zinc-300">
                            Priority: <span className="text-amber-400 capitalize">{action.priority}</span>
                          </span>
                          <span className="text-xs font-semibold px-2 py-1 rounded bg-white/5 text-zinc-300">
                            Impact: <span className="text-emerald-400">-{action.scoreImpact} pts</span>
                          </span>
                        </div>
                      </div>
                      
                      <button
                        onClick={() => handleApplyAction(action.id)}
                        disabled={action.applied || applyActionMutation.isPending}
                        className={cn(
                          "shrink-0 px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 transition-all duration-300",
                          action.applied 
                            ? "bg-emerald-500/10 text-emerald-500 cursor-not-allowed border border-emerald-500/20" 
                            : "bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_rgba(6,182,212,0.2)] hover:shadow-[0_0_20px_rgba(6,182,212,0.4)]"
                        )}
                      >
                        {action.applied ? "Applied" : "Apply Fix"}
                        {!action.applied && <ArrowRight className="w-4 h-4" />}
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </motion.div>

            <motion.div variants={itemVariants} className="space-y-4">
              <h3 className="font-display font-bold text-xl mb-2">AI Insights</h3>
              
              {currentScan.insights.map(insight => (
                <div 
                  key={insight.id}
                  className="glass-panel rounded-xl p-5 flex items-start gap-4 hover:bg-white/5 transition-colors"
                >
                  <div className={cn(
                    "p-2 rounded-lg border shrink-0 mt-1",
                    insight.severity === 'danger' ? "bg-rose-500/10 text-rose-500 border-rose-500/20" :
                    insight.severity === 'warning' ? "bg-amber-500/10 text-amber-500 border-amber-500/20" :
                    "bg-blue-500/10 text-blue-500 border-blue-500/20"
                  )}>
                    {insight.severity === 'danger' ? <ShieldAlert className="w-5 h-5" /> : 
                     insight.severity === 'warning' ? <AlertTriangle className="w-5 h-5" /> : 
                     <Info className="w-5 h-5" />}
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider mb-1">
                      {insight.category}
                    </h4>
                    <p className="text-foreground leading-relaxed">{insight.text}</p>
                  </div>
                </div>
              ))}
              
              {isHighRisk && (
                <div className="mt-6 p-5 rounded-xl bg-gradient-to-r from-rose-500/10 to-transparent border border-rose-500/20 flex items-start gap-4">
                  <ShieldAlert className="w-6 h-6 text-rose-500 shrink-0" />
                  <div>
                    <h4 className="font-bold text-rose-500 mb-1">Critical Attention Required</h4>
                    <p className="text-sm text-rose-200/70">
                      Your identity footprint is highly exposed. Prioritize applying the recommended security actions above immediately to mitigate takeover risks.
                    </p>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
