import React, { createContext, useContext, useState, ReactNode } from "react";
import type { ScanResult } from "@workspace/api-client-react";

interface AppState {
  currentScan: ScanResult | null;
  setCurrentScan: (scan: ScanResult | null) => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentScan, setCurrentScan] = useState<ScanResult | null>(null);

  return (
    <AppContext.Provider value={{ currentScan, setCurrentScan }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppStore() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useAppStore must be used within an AppProvider");
  }
  return context;
}
