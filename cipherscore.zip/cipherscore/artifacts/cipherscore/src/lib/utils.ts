import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getRiskColor(score: number): string {
  if (score <= 33) return "#10b981";  // emerald-500
  if (score <= 66) return "#f59e0b";  // amber-500
  if (score <= 84) return "#f97316";  // orange-500
  return "#ef4444";                   // red-500
}

export function getRiskCategoryLabel(category: string): string {
  switch (category) {
    case "low": return "Low Risk";
    case "medium": return "Medium Risk";
    case "high": return "High Risk";
    case "critical": return "Critical Risk";
    default: return "Unknown";
  }
}

export function getRiskCategoryColorClass(category: string): string {
  switch (category) {
    case "low": return "text-emerald-400 bg-emerald-400/10 border-emerald-400/20";
    case "medium": return "text-amber-400 bg-amber-400/10 border-amber-400/20";
    case "high": return "text-orange-400 bg-orange-400/10 border-orange-400/20";
    case "critical": return "text-rose-400 bg-rose-400/10 border-rose-400/20";
    default: return "text-zinc-400 bg-zinc-400/10 border-zinc-400/20";
  }
}
