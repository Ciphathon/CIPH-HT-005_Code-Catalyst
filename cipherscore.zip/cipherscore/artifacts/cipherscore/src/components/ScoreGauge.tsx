import { motion } from "framer-motion";
import { getRiskColor } from "@/lib/utils";

interface ScoreGaugeProps {
  score: number;
  category: string;
}

export function ScoreGauge({ score, category }: ScoreGaugeProps) {
  const radius = 60;
  const strokeWidth = 12;
  const normalizedRadius = radius - strokeWidth / 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (score / 100) * circumference;
  
  const color = getRiskColor(score);

  return (
    <div className="relative flex flex-col items-center justify-center py-6">
      <div className="relative flex items-center justify-center w-48 h-48">
        {/* Background Track */}
        <svg height={radius * 2} width={radius * 2} className="transform -rotate-90 drop-shadow-xl">
          <circle
            stroke="currentColor"
            fill="transparent"
            strokeWidth={strokeWidth}
            r={normalizedRadius}
            cx={radius}
            cy={radius}
            className="text-zinc-800"
          />
          {/* Animated Progress Ring */}
          <motion.circle
            stroke={color}
            fill="transparent"
            strokeWidth={strokeWidth}
            strokeDasharray={circumference + " " + circumference}
            style={{ strokeDashoffset: circumference }}
            strokeLinecap="round"
            r={normalizedRadius}
            cx={radius}
            cy={radius}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.5, ease: "easeOut", delay: 0.2 }}
            className="drop-shadow-[0_0_8px_rgba(0,0,0,0.5)]"
          />
        </svg>
        
        {/* Score Value Display */}
        <div className="absolute flex flex-col items-center justify-center">
          <motion.span 
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="text-5xl font-display font-bold text-foreground"
          >
            {score}
          </motion.span>
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mt-1">
            Risk Score
          </span>
        </div>
      </div>
      
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 1 }}
        className="mt-4 flex flex-col items-center"
      >
        <span className="text-sm text-muted-foreground mb-1">Status</span>
        <span 
          className="px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-widest bg-opacity-10 border"
          style={{ color, borderColor: color, backgroundColor: `${color}1A` }}
        >
          {category}
        </span>
      </motion.div>
    </div>
  );
}
