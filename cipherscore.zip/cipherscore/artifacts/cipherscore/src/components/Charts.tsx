import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, CartesianGrid, Cell, Legend,
} from "recharts";
import type { RiskFactor, ScanSummary } from "@workspace/api-client-react";
import { getRiskColor } from "@/lib/utils";

interface RiskVectorsChartProps {
  factors: RiskFactor[];
}

export function RiskVectorsChart({ factors }: RiskVectorsChartProps) {
  const data = factors.map((f) => ({
    name: f.label.replace(" ", "\n"),
    score: f.score,
    color: getRiskColor(f.score),
  }));

  return (
    <div className="w-full h-64 mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
          <XAxis
            dataKey="name"
            tick={{ fill: "#a1a1aa", fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            interval={0}
          />
          <YAxis
            tick={{ fill: "#a1a1aa", fontSize: 12 }}
            tickLine={false}
            axisLine={false}
            domain={[0, 100]}
          />
          <Tooltip
            cursor={{ fill: "#27272a", opacity: 0.4 }}
            contentStyle={{
              backgroundColor: "#18181b",
              border: "1px solid #3f3f46",
              borderRadius: "8px",
              color: "#fafafa",
              boxShadow: "0 10px 15px -3px rgba(0,0,0,0.5)",
            }}
            formatter={(value: number) => [`${value}/100`, "Risk Score"]}
          />
          <Bar dataKey="score" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

interface ScoreHistoryChartProps {
  history: ScanSummary[];
}

export function ScoreHistoryChart({ history }: ScoreHistoryChartProps) {
  const data = [...history].reverse().map((h) => ({
    date: new Date(h.scannedAt).toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
    }),
    score: Math.round(h.riskScore),
  }));

  return (
    <div className="w-full h-64 mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
          <XAxis
            dataKey="date"
            tick={{ fill: "#a1a1aa", fontSize: 12 }}
            tickLine={false}
            axisLine={false}
          />
          <YAxis
            tick={{ fill: "#a1a1aa", fontSize: 12 }}
            tickLine={false}
            axisLine={false}
            domain={[0, 100]}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#18181b",
              border: "1px solid #3f3f46",
              borderRadius: "8px",
              color: "#fafafa",
              boxShadow: "0 10px 15px -3px rgba(0,0,0,0.5)",
            }}
            formatter={(value: number) => [value, "Risk Score"]}
          />
          <Line
            type="monotone"
            dataKey="score"
            stroke="#06b6d4"
            strokeWidth={3}
            dot={{ fill: "#06b6d4", strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6, strokeWidth: 0 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

interface MultiLineHistoryChartProps {
  data: { date: string; [email: string]: number | string }[];
  emails: string[];
}

const LINE_COLORS = ["#06b6d4", "#a78bfa", "#f59e0b", "#10b981", "#f97316"];

export function MultiLineHistoryChart({ data, emails }: MultiLineHistoryChartProps) {
  return (
    <div className="w-full h-72">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
          <XAxis
            dataKey="date"
            tick={{ fill: "#a1a1aa", fontSize: 12 }}
            tickLine={false}
            axisLine={false}
          />
          <YAxis
            tick={{ fill: "#a1a1aa", fontSize: 12 }}
            tickLine={false}
            axisLine={false}
            domain={[0, 100]}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#18181b",
              border: "1px solid #3f3f46",
              borderRadius: "8px",
              color: "#fafafa",
            }}
          />
          <Legend
            wrapperStyle={{ fontSize: "12px", color: "#a1a1aa", paddingTop: "16px" }}
          />
          {emails.map((email, i) => (
            <Line
              key={email}
              type="monotone"
              dataKey={email}
              stroke={LINE_COLORS[i % LINE_COLORS.length]}
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 5 }}
              name={email}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
