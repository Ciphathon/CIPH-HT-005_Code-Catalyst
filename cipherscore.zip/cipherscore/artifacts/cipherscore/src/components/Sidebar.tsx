import { Link, useLocation } from "wouter";
import { Shield, Activity, Clock, Settings, Search, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: Activity },
    { href: "/", label: "New Scan", icon: Search },
    { href: "/history", label: "Scan History", icon: Clock },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <aside className="fixed inset-y-0 left-0 w-64 glass-panel border-y-0 border-l-0 z-40 hidden md:flex flex-col">
      <div className="flex items-center gap-3 px-6 py-8">
        <div className="bg-primary/20 p-2 rounded-xl border border-primary/30 text-primary">
          <Shield className="w-6 h-6" />
        </div>
        <span className="font-display font-bold text-xl tracking-wide text-foreground">
          Cipher<span className="text-primary">Score</span>
        </span>
      </div>

      <div className="px-4 py-2 flex-1">
        <div className="space-y-1">
          <p className="px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">
            Intelligence
          </p>
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <Link 
                key={item.href} 
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden",
                  isActive 
                    ? "text-primary bg-primary/10 font-medium" 
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                )}
              >
                {isActive && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary rounded-r-md" />
                )}
                <Icon className={cn("w-5 h-5 transition-transform", isActive ? "scale-110" : "group-hover:scale-110")} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </div>

      <div className="p-4 border-t border-white/5">
        <button className="flex items-center gap-3 px-4 py-3 w-full rounded-xl text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors duration-200">
          <LogOut className="w-5 h-5" />
          <span>Disconnect</span>
        </button>
      </div>
    </aside>
  );
}
